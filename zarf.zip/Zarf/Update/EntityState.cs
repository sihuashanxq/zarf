﻿namespace Zarf.Update
{
    public enum EntityState
    {
        Insert,
        Update,
        Delete
    }
}

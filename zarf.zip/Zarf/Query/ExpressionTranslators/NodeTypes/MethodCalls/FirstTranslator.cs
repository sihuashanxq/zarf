﻿using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Zarf.Entities;
using Zarf.Extensions;
using Zarf.Query.Expressions;

namespace Zarf.Query.ExpressionTranslators.Methods
{
    public class FirstTranslator : Translator<MethodCallExpression>
    {
        public static IEnumerable<MethodInfo> SupprotedMethods { get; }

        static FirstTranslator()
        {
            SupprotedMethods = ReflectionUtil.QueryableMethods.Where(item => item.Name == "First" || item.Name == "FirstOrDefault");
        }

        public FirstTranslator(IQueryContext queryContext, IQueryCompiler queryCompiper) : base(queryContext, queryCompiper)
        {

        }

        public override Expression Translate(MethodCallExpression methodCall)
        {
            var query = GetCompiledExpression<QueryExpression>(methodCall.Arguments[0]);
            if (methodCall.Arguments.Count == 2)
            {
                if (query.Sets.Count != 0)
                {
                    query = query.PushDownSubQuery(Context.Alias.GetNewTable());
                    query.Result = query.SubQuery.Result;
                }

                MapParameterWithQuery(GetFirstParameter(methodCall.Arguments[1]), query);
                var where = GetCompiledExpression(methodCall.Arguments[1]);
                where = HandleCondtion(where);
                query.CombineCondtion(where);
            }

            query.DefaultIfEmpty = methodCall.Method.Name == "FirstOrDefault";
            query.Limit = 1;
            return query;
        }
    }
}

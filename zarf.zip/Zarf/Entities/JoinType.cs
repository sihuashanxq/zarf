﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zarf.Entities
{
    public enum JoinType
    {
        Left,
        Right,
        Full,
        Inner,
        Cross
    }
}

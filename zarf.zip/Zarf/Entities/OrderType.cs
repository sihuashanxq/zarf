﻿namespace Zarf.Entities
{
    /// <summary>
    /// 数据排序方式
    /// </summary>
    public enum OrderType
    {
        Asc,
        Desc
    }
}

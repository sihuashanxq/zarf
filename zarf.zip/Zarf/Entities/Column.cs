﻿namespace Zarf.Entities
{
    public class Column
    {
        public string Name { get; }

        public Column(string name)
        {
            Name = name;
        }
    }
}
